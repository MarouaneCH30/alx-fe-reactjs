function Header() {

    return (
        <header>
            <h1>My Favorite Cities</h1>
        </header>
    )
}

export default Header;
